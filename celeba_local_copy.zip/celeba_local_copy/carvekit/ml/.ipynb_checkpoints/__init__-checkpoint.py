from carvekit.utils.models_utils import fix_seed, suppress_warnings

fix_seed()
suppress_warnings()
